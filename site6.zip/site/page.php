<?php
$id = $_GET['id'];
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include 'cadastro/cadastro.php';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Máquina</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body { font: 14px sans-serif; text-align: center; }
        .chart-container {
            width: 50%;
            margin: 0 auto;
        }
        .container {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
        }
        .item {
            background-color: #f0f0f0;
            border: 1px solid #ccc;
            padding: 20px;
            text-align: center;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            min-height: 200px;
            flex-grow: 1;
        }
        .btn-xl {
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 10px;
            width: 15%;
        }
    </style>
</head>
<body>
    <a href="https://carlitoslocacoes.com/site/welcome.php" class="btn btn-primary btn-xl">Início</a>

    <div class="page-header">
        <h1>Olá, Seja Bem-Vindo.</h1>
        <form method="GET" action="page.php">
            <label for="id">Busque por ID:</label>
            <input type="text" id="id" name="id" required>
            <button type="submit">Buscar</button>
        </form>
    </div>

    <?php
    // Database connection
    $cx = mysqli_connect("127.0.0.1", "u839226731_cztuap", "Meu6595869Trator");
    mysqli_select_db($cx, "u839226731_meutrator");
    $eq_user = $_SESSION["username"];

    // Fetch results for given ID
    $sql = mysqli_query($cx, "SELECT DISTINCT id, tipo FROM respostas2 WHERE cv = '$id' AND eq_user = '$eq_user'") or die(mysqli_error($cx));

    // Output results
    while ($aux = mysqli_fetch_assoc($sql)) {
        echo '<div class="item col-xs-10 col-sm-2">';
        echo "" . $aux["tipo"] . "<br><br>";
        echo '</div>';
    }
    ?>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <div class="container-fluid bg-3">
        <canvas id="grafico1"></canvas>
    </div>

    <?php
    include 'juggergym.php';

    use JuggerGym\minhaFuncao;
    use JuggerGym\variavelJuggerGym;

    minhaFuncao();
    echo $variavelJuggerGym;
    ?>
</body>
</html>
