<!DOCTYPE html>
<html lang="pt">
<head>
  <title>Carlito's Locações - ID Barbante</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Locação de máquinas e equipamentos para linha de transmissão.">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <style>
  .carousel-caption {
    background-color: rgba(0, 0, 0, 0.5); 
    padding: 10px;
  }

  .img-circle-custom {
    border-radius: 50%;
    width: 100px;
    height: 100px;
    object-fit: cover;
  }

  body {
    font: 22px Montserrat, sans-serif;
    line-height: 1.8;
    color: #f5f6f7;
  }

  p {
    font-size: 16px;
  }

  .margin {
    margin-bottom: 45px;
  }

  .bg-1, .bg-2, .bg-3, .bg-4, .bg-9 {
    background-color: #6d0505;
    color: #ffffff;
  }

  .small-font {
    font: 16px Montserrat, sans-serif;
  }

  .container-fluid {
    padding-top: 10px;
    padding-bottom: 10px;
  }

  .navbar {
    padding-top: 3px;
    padding-bottom: 3px;
    border: 0;
    border-radius: 0;
    margin-bottom: 0;
    font-size: 11px;
    letter-spacing: 5px;
  }

  .navbar-nav li a:hover {
    color: #1abc9c !important;
  }

  .carousel-inner > .item > img,
  .carousel-inner > .item > a > img {
    display: block;
    height: 500px;
    min-width: 100%;
    width: 100%;
    max-width: 100%;
    line-height: 1;
  }

  input {
    color: black;
  }

  /* Centralizando as tabelas nos containers */
  .table-container {
    display: flex;
    justify-content: center; /* Alinha horizontalmente */
    align-items: center;    /* Alinha verticalmente */
  }

  .table {
    margin: auto; /* Garante que a tabela esteja centralizada dentro do div */
  }

  /* Estilizando botões para contraste */
  button {
    background-color: #1abc9c; /* Cor de fundo visível */
    color: #ffffff; /* Cor do texto clara */
    font-size: 16px; /* Tamanho do texto */
    padding: 10px 20px; /* Espaçamento interno */
    border: none; /* Sem borda */
    border-radius: 5px; /* Borda arredondada */
    cursor: pointer; /* Cursor em formato de botão */
  }

  button:hover {
    background-color: #16a085; /* Cor de fundo ao passar o mouse */
  }

  @import url("https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css");
</style>


</head>
<body>
<nav class="navbar navbar-default">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="../">Carlito's Locações</a>
      <a class="navbar-brand" href="tel:+5555996479747">(55) 9.9647-9747</a>
    </div>
     </div>
</nav>

<div class="container-fluid bg-1 text-center">
  <img src="/site2/carlitoschapeu.png" width="300" height="300">
  <img src="/site2/fontcarlitos.png" width="400" height="400">
</div>

<div class="container-fluid bg-2 text-center">
 
  
   <center><p>   <a href="https://carlitoslocacoes.com/site/welcome.php" class="btn btn-primary">Ir para Página Principal</a></p></center>
  <form method="GET" action="../site/msg.php">
    <label for="id">ID para Enviar Mensagem:</label>
    <input type="text" id="id" name="id" required>
    <button type="submit">Buscar</button><br>
    </form><br>
  <form method="GET" action="../site/page.php">
    <label for="id">ID para Ler Mensagem:</label>
    <input type="text" id="id" name="id" required>
    <button type="submit">Buscar</button>
    </form><br>
   
</div>


   

<!-- Footer -->
<footer class="container-fluid bg-4 text-center">



<p>Desenvolvido por Carlito Veeck Pautz Júnior.</p> 
 <img src="//ipv6.he.net/certification/create_badge.php?pass_name=carlitopautz&amp;badge=1" style="border: 0; width: 128px; height: 128px" alt="Selo de certificação IPv6 para Carlito Pautz">
<p xmlns:cc="http://creativecommons.org/ns#" xmlns:dct="http://purl.org/dc/terms/"><a property="dct:title" rel="cc:attributionURL" href="http://carlitoslocacoes.com/site2">Carlito's Locações</a> by <a rel="cc:attributionURL dct:creator" property="cc:attributionName" href="http://carlitoslocacoes.com/pofft">Carlito Veeck Pautz Júnior</a> is licensed under <a href="https://creativecommons.org/licenses/by/4.0/?ref=chooser-v1" target="_blank" rel="license noopener noreferrer" style="display:inline-block;">Creative Commons Attribution 4.0 International<img style="height:22px!important;margin-left:3px;vertical-align:text-bottom;" src="https://mirrors.creativecommons.org/presskit/icons/cc.svg?ref=chooser-v1" alt=""><img style="height:22px!important;margin-left:3px;vertical-align:text-bottom;" src="https://mirrors.creativecommons.org/presskit/icons/by.svg?ref=chooser-v1" alt=""></a></p>
</footer>

</body>
</html>
